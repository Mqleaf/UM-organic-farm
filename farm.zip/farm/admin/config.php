<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 2016/9/16
 * Time: 11:08
 */
define('DB_HOST','localhost');
define('DB_NAME', 'web_gmx');
define('DB_USER', 'root');
define('DB_PWD', '');
