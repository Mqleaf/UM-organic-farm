<?php
include_once('db_fns.php');
include_once('output_fns.php');
include_once('product_fns.php');
include_once('order_fns.php');
include_once('validate_fns.php');
?>